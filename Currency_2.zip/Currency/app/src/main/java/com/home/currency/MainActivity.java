package com.home.currency;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.BlockingDeque;

public class MainActivity extends AppCompatActivity {

    private EditText ntu;
    private TextView resualt_jpy;
    private TextView resualt_usd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }

    private void findViews() {
        ntu = findViewById(R.id.ed_ntd);
        resualt_jpy = findViewById(R.id.resualt_jpy);
        resualt_usd = findViewById(R.id.resualt_usd);
    }

    public void GO (View view){
        if ("".equals(ntu.getText().toString())){
            new AlertDialog.Builder(this)
                    .setTitle(R.string.problem)
                    .setMessage(R.string.please_enter_ntd)
                    .setPositiveButton("OK", null)
                    .show();
        }else {
            String u = ntu.getText().toString();
            float nt_to_us = Float.parseFloat(u);
            float nt_to_jp = Float.parseFloat(u);
            float jpy = nt_to_jp / 0.27f;
            float usd = nt_to_us / 30.9f;
            resualt_jpy.setText(": " + String.format("%.2f", jpy));
            resualt_usd.setText(": " + String.format("%.2f", usd));
            new AlertDialog.Builder(this)
                    .setTitle(R.string.resualt)
                    .setMessage(getString(R.string.usd_is) + String.format("%.2f", usd))
                    .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ntu.setText("");
                            resualt_jpy.setText(R.string.none);
                            resualt_usd.setText(R.string.none);
                        }
                    })
                    .show();
        }
      }
}